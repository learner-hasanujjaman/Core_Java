package com.JDBC;

//DBDriver -> JDBC connector provided by sun microsystems
interface DBDriver {
	void registerDriver();
	void connect();
}

//Connection with Oracle DB
class OracleDriver implements DBDriver{
	public void registerDriver() {
		System.out.println("Oracle driver registered.");
	}
	public void connect() {
		System.out.println("Connection b/w Java and Oracle is establised.");
	}
}


//Connection with MySQL DB
class SqlDriver implements DBDriver{
	public void registerDriver() {
		System.out.println("MySQL driver registered.");
	}
	public void connect() {
		System.out.println("Connection b/w Java and MySQL is establised.");
	}
}

//Connection with DB2
class DB2Driver implements DBDriver{
	public void registerDriver() {
		System.out.println("DB2 driver registered.");
	}
	public void connect() {
		System.out.println("Connection b/w Java and DB2 is establised.");
	}
}

public class TestConnection {

	public static void main(String[] args) {
		//calling Oracle DB
		DBDriver oracleDriver = new OracleDriver();
		oracleDriver.registerDriver();
		oracleDriver.connect();
		
		//calling SQL DB
		DBDriver sqlDriver = new SqlDriver();
		sqlDriver.registerDriver();
		sqlDriver.connect();
		
		//calling DB2 DB
		DBDriver db2Driver = new DB2Driver();
		db2Driver.registerDriver();
		db2Driver.connect();
		

	}

}
