package com.stringmanipulation;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

public class TestString {

	public static void main(java.lang.String[] args) {
		
		//Constructor 1 ->	empty string
		String str1 = new String();
		System.out.println("Str1 : "+ str1);  //overriding toString() by default
		System.out.println("Str1 value : "+ str1.toString());
		System.out.println("Str1 hashcode : "+ str1.hashCode());  // 0 is hashcode for empty string
		System.out.println();
		
		//Constructor 2 -> string with some value 	
		String str2 = new String("New string");
		System.out.println("Str1 : "+ str2);
		System.out.println("Str1 hashcode : "+ str2.hashCode());   // hashcode generated as value added
		System.out.println();
		
		//Constructor 3	-> string from byte array
		byte[] byteArray = { 'P', 'A', 'N', 'K', 'A', 'J' };
		byte[] byteArray1 = { 80, 65, 78, 75, 65, 74 };    //-> ASCII values of chars

		String str3 = new String(byteArray);
		String str4 = new String(byteArray1);

		System.out.println("String from char byte array - " + str3);
		System.out.println("String from index byte array - " + str4);
		
		byte[] b = {65,66,67,68,69,70};
		String str5 = new String(b);
		System.out.println("String from index byte array - " + str5);
		System.out.println();
		
		//Constructor 4	-> string from byte array with conditions
		//String(byte[] b; int startIndex, int noOfElements)
		String str6 = new String(byteArray, 1,3);
		System.out.println(str6);
		System.out.println();
		
		
		//Constructor 5	-> string from char array
		char[] charArray = { 'P', 'A', 'N', 'K', 'A', 'J' };
		String str7 = new String(charArray);
		System.out.println("String from char byte array - " + str7);
		System.out.println();
		
		
		//Constructor 6	-> string from char array with conditions
		//String(char[] ch; int startIndex, int noOfElements)
		String str8 = new String(charArray, 1,3);
		System.out.println(str8);
		System.out.println();
		
		//Constructor 7	-> string using stringBuffer object
		// Converting Mutable(String) to Immutable(StringBuffer)
		StringBuffer sbuffer = new StringBuffer("Using String Buffer Object.");
		System.out.println("string buffer -> "+ sbuffer);
		String str9 = new String(sbuffer);
		System.out.println(str9);
		System.out.println();
		
		
		//Constructor 8	-> string using stringBuilder object
		// Converting Mutable(String) to Immutable(StringBuilder)
		StringBuilder sbuilder = new StringBuilder("Using String Builder Object.");
		System.out.println("string builder -> "+ sbuilder);
		String str10 = new String(sbuilder);
		System.out.println(str10);
		System.out.println();
		
		
		//Constructor 9 -> string from character array with encoding 
		String str11 = new String(byteArray, Charset.defaultCharset());
		System.out.println("String with Charset encoding - "+str11);
		System.out.println();
		
		//Constructor 10 -> string from character array with condition and encoding 
		String str12 = new String(byteArray, 1, 3, Charset.defaultCharset());
		System.out.println("String with Charset encoding - "+str12);
		System.out.println();
		
		//Constructor 11 -> string from character array with condition and encoding 

		System.out.println("Check is charset is supported by present JVM -------");
		System.out.println("US-ASCII -"+Charset.isSupported("US-ASCII"));
		System.out.println("ISO-8859-1 -"+Charset.isSupported("ISO-8859-1"));
		System.out.println("UTF-8 -"+Charset.isSupported("UTF-8"));
		System.out.println("UTF-16 -"+Charset.isSupported("UTF-16"));
		System.out.println("UTF-16BE -"+Charset.isSupported("UTF-16BE"));
		System.out.println("UTF-16LE -"+Charset.isSupported("UTF-16LE"));
		System.out.println("default -"+Charset.defaultCharset());

		System.out.println();
		String str13 = new String(byteArray, Charset.forName("UTF-16"));
		System.out.println("String with Charset encoding - "+str13);
	}

}
