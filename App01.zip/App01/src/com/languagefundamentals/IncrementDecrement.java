package com.languagefundamentals;

public class IncrementDecrement {
	
	public static void main(String[] args) {
		
		int a = 23;
		int b = 23;
		// ++a -> pre-increment .. increment -> display 
		System.out.println(++a);   
		// b++ -> post-increment .. display -> increment
		System.out.println(b++);  //increment happens after display
		System.out.println(b);
		
		//same with decrement
		
		int n = 5;
		System.out.println(++n + n-- * --n + --n);
		//.................  6 + 6   *   4 + 3  = 33
		
		int i = 6;
		System.out.println((++i + --i)*(i-- + --i)-(++i + --i)*(--i - ++i));
		//................. (7+6)*(6+4)-(5+4)*(3-4) = 13*10 - 9*(-1) = 139
	}

}
