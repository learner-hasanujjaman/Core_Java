package com.languagefundamentals;

public class BreakStatement {

	public static void main(String[] args) {
		/*
		 * Normal break statement impacts on current loop of swith-case statement
		 * Labeled break statement impacts on the loop where that label is located
		 */
		
		for (int i=0; i<5; i++) {
			p1:for(int j=0; j<5; j++) {
				for(int l=0; l<5; l++) {
					System.out.println(i+" "+j+" "+l);
					if(l==1) {
						break p1;
					}
				}
			}
		}
		
		/*
		 * p1 - label for break statement
		 * this break statement will terminate 2nd for loop
		 */

	}

}
