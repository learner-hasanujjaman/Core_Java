package com.languagefundamentals;

public class TypeCasting {

	public static void main(String[] args) {
		
		byte b = 66;
		char c = (char) b;
		System.out.println("b : "+b);
		System.out.println("c : "+c);
		// c <-- B as 66 represents "B" ascii character
		// byte to char is only possible for Explicit Type Casting and not available for Implicit
		// ASCII table -> https://www.cs.cmu.edu/~pattis/15-1XX/common/handouts/ascii.html
	
		
		char p = 'B';
		short q = (short) p;
		System.out.println("p : "+p);
		System.out.println("q : "+q);
		
		
		int f = 178;
		byte g = (byte)f;
		System.out.println("f : "+f);
		System.out.println("g : "+g);
		
		/*
		 * g = 178 - 127(higher range value) = 51 - 1 = 50 +(-128)(lower range value) = - 78
		 * -128 <= byte value <= 127 
		 * but this goes on cycle
		 */
	
	}

}
