package com.languagefundamentals;

public class NumberSystem {

	public static void main(String[] args) {
		/* 1. Binary Number System [BASE - 2]
		 * Alphabet : 0s and 1s
		 * Prefix : 0b | 0B
		 */
		int biNum = 0b10110;
		int biNum2 = 0B10110;
		System.out.println("biNum - "+biNum);
		System.out.println("biNum2 - "+biNum2);
		System.out.println("--------------------------");
		
		
		/* 2. Octal Number System [BASE - 8]
		 * Alphabet : 0,1,2,3,4,5,6,7 | >8 is not allowed
		 * Prefix : 0 [zero]
		 * online octal -> decimal => https://www.rapidtables.com/convert/number/octal-to-decimal.html?
		 */
		
		int octNum = 025321;  //--> 64
		int octNum2 = 0234;  //--> 64
//		int octNum2 = 0238;   //---> >8 if present -> out of range 
		System.out.println("octNum - "+octNum);
		System.out.println("octNum2 - "+octNum2);
		System.out.println("--------------------------");
		

		/* 3. Decimal Number System [BASE - 10]
		 * Alphabet : 0,1,2,3,4,5,6,7,8,9 | >9 is not allowed
		 * Prefix : no prefix needed as this is default number system in java 
		 */
		
		int decNum = 234681477;
		System.out.println("decNum - "+decNum);
		System.out.println("--------------------------");
		
		
		/* 4. Hexa Decimal Number System [BASE - 16]
		 * Alphabet : 0,1,2,3,4,5,6,7,8,9,a,b,c,d,e,f | >f=16 is not allowed
		 * a=10, b=11, c=12, d=13, e=14, f=15
		 * Prefix : 0x | 0X
		 */
		
		int hexNum = 0x23;
		System.out.println("hexNum = "+ hexNum);
		System.out.println("--------------------------");
		
		
		/*
		 * Can we perform operations with mix number systems?
		 * -> Yes.
		 */
		
		int firstNum = 0233;
		int secondNum = 0x24;
		int thirdNum = 0b10101;
		System.out.println(firstNum);
		System.out.println(secondNum);
		System.out.println(thirdNum);
		System.out.println(firstNum + secondNum + thirdNum);
		System.out.println("--------------------------");
		
		/*
		 * Convert a number in different number system
		 */
		//decimal to other number systems
		int decNum3 = 15;
		
		String biNum3 = Integer.toBinaryString(decNum3);
		String octNum3 = Integer.toOctalString(decNum3);
		String hexNum3 = Integer.toHexString(decNum3);
		
		System.out.println("Conversion between number systems --------");
		System.out.println(biNum3);
		System.out.println(octNum3);
		System.out.println(hexNum3);
		
		
		//convert other than decimal numbers to other than decimal number.
		int octNum4 = 023;
		String hexNum4 = Integer.toHexString(octNum4);  
		//octNum4 value has been changed to integer by now by JVM
		System.out.println(hexNum4);
		System.out.println("--------------------------");
		
		
		//convert other than decimal numbers to decimal number.
		
		//Binary to Decimal
		int biNum5 = 0b1010;
		System.out.println(biNum5);
		
		String biNum6 = "1010";
		int decNum6 = Integer.parseInt(biNum6, 2);
		System.out.println(decNum6);
		
		//Octal to Decimal 
		int octNum5 = 0233;
		System.out.println(octNum5);
		
		String octNum6 = "233";
		int decNum7 = Integer.parseInt(octNum6, 8);
		System.out.println(decNum7);
		
		//Hexa decimal to Decimal
		int hexNum5 = 0x123;
		System.out.println(hexNum5);
		
		String hexNum6 = "123";
		int decNum8 = Integer.parseInt(hexNum6, 16);
		System.out.println(decNum8);
		
	}

}
