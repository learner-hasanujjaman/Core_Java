package com.languagefundamentals;

public class Literals {

	public static void main(String[] args) {
		//Literal - literal is a constant that is assigned to a variable
		
		//integral literal - byte|short|int|long|char
		int a = 10;
		char ch = 's';
		System.out.println("integer value : "+a);
		System.out.println("character value : "+ch);
		
		System.out.println("type of a : "+ ((Object)a).getClass().getSimpleName());
		System.out.println("type of ch : "+ ((Object)ch).getClass().getSimpleName());
		
		
		//string literals
		String str = "hasan";
		System.out.println("type of str " +str.getClass().getSimpleName());

		
		// in above JAVA7 versions, we can use "_" inside numbers to 
        // increase readability for developers, but JVM will consider it as 
		// a single number
		int val1 = 12_5_32;
		int val2 = 12_5_32;
		System.out.println("printing value of val "+val1);
		System.out.println(val1+val2);
	}

}
