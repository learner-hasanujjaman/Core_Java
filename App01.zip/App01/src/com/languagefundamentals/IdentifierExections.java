package com.languagefundamentals;

public class IdentifierExections {
	
	public static void main(String[] args) {
		int System = 10;
		java.lang.System.out.println(System);
//		System.out.println(System);    -- this will not work as We have used System as identifier of int value
	}
	

}
