package com.languagefundamentals;

public class Operators {
	
	public static void doubleOrOperator() {
		int a = 20;
		int b = 20;
		int i = 20;
		int j = 20;
		
		if(a++ == 20 | b++ == 20) {
			System.out.println(a + " "+ b);
			// JVM has executed both a and b to conclude OR(|) operator result
		}
		
		if(i++ == 20 || j++ == 20) {
			System.out.println(i + " "+ j);
			// JVM has executed only i to conclude OR(||) operator result
			//less execution time --> more efficiency 
		}
	}
	
	public static void doubleAndOperator() {
		int a = 20;
		int b = 20;
		int i = 20;
		int j = 20;
		
		if(a++ == 10 & b++ == 20) {
			System.out.println("wrong executed block!");
		}else {
			System.out.println(a + " "+ b);
			// JVM has executed both a and b to conclude AND(&) operator result
		}
		
		if(i++ == 10 && j++ == 20) {
			System.out.println("wrong executed block!");
		}else {
			System.out.println(i + " "+ j);
			// JVM has executed only i to conclude AND(&&) operator result
			//less execution time --> more efficiency 
		}
	}
	
	
	public static void main(String[] args) {
		System.out.println("Executing || operator ----------------");
		doubleOrOperator();
		System.out.println("Executing && operator ----------------");
		doubleAndOperator();
			
	}
	
	
	

}
