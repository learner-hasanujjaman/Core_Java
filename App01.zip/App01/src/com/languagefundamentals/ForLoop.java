package com.languagefundamentals;

public class ForLoop {

	public static void main(String[] args) {
		
		//case 1:
		int a = 0;
		System.out.println("printing a values -------------------");
		for(; a<5; a++) {
			System.out.print(a+" ");
		}
		/*
		 * exp1 is optional, if we already have initialized the loop variable
		 */
		
		//case2
		/*
		for)(int b=0, int c=0; b<10 && c<10; b++, c++){
			System.out.println(b+ " "+c);
		}
		This is giving error as we have more than one declarative statement in
		for() signature
		*/

		//case3
		for(int b=0, c=0; b<10 && c<10; b++, c++){
			System.out.println(b+ " "+c);
		}
		
		/*this is working as we have multiple variable in for() signature but 
		 having only one Declarative statement.
		 
		 So, multiple variables are fine but we must have only one Declarative statement 
		 in the for () signature statement
		 */
	}

}
