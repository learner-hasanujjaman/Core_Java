package com.languagefundamentals;

public class BitwiseOperator {
	
	public static void main(String[] args) {
		/*
		 * Bitwise Operators - operates in similar fashion as normal truth tables
		 * If we provide numbers as Integer, it will convert the numbers to 
		 * binary and then perform operations as per truth tables
		 */
		
		int a = 10;
		int b = 15;
		
		System.out.println("a&b : "+ (a&b));
		System.out.println("a|b : "+ (a|b));
		System.out.println("a^b : "+ (a^b));
		System.out.println("a>>b : "+ (a>>b));
		System.out.println("a<<b : "+ (a<<b));
		
	}

}
