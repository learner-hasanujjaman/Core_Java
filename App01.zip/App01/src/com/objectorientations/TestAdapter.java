package com.objectorientations;

import java.awt.event.WindowEvent;

/*
 * Adapter class - Intermediate class between Interface and Implement class
 * 
 * -- reduce implementing unnecessary methods on implementing an Interface
 */


interface WindowListener{
	public void windowOpened(WindowEvent we);
	public void windowClosed(WindowEvent we);
	public void windowClosing(WindowEvent we);
	public void windowIconified(WindowEvent we);
	public void windowDeiconified(WindowEvent we);
	public void windowActivated(WindowEvent we);
	public void windowDeactivated(WindowEvent we);
	
}

class WindowAdapter implements WindowListener{

	@Override
	public void windowOpened(WindowEvent we) {
	}

	@Override
	public void windowClosed(WindowEvent we) {
	}

	@Override
	public void windowClosing(WindowEvent we) {
	}

	@Override
	public void windowIconified(WindowEvent we) {
	}

	@Override
	public void windowDeiconified(WindowEvent we) {
	}

	@Override
	public void windowActivated(WindowEvent we) {
	}

	@Override
	public void windowDeactivated(WindowEvent we) {
	}
	
}

class FirstClass extends WindowAdapter{
	@Override
	public void windowOpened(WindowEvent we) {
		System.out.println("Window Opened");
	}
}

class SecondClass extends WindowAdapter{
	@Override
	public void windowClosed(WindowEvent we) {
		System.out.println("Window Closed");
	}
}

class ThirdClass extends WindowAdapter{
	@Override
	public void windowActivated(WindowEvent we) {
		System.out.println("Window Activated");
	}
}


public class TestAdapter {

	public static void main(String[] args) {
		WindowEvent we = null;
		FirstClass fc = new FirstClass();
		fc.windowOpened(we);
		System.out.println();
		
		SecondClass sc = new SecondClass();
		sc.windowClosed(we);
		System.out.println();
		
		ThirdClass tc = new ThirdClass();
		tc.windowActivated(we);
		System.out.println();
	}
	

}
