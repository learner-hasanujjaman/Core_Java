package com.objectorientations;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Serialization implements Serializable{

	private static final long serialVersionUID = 1L;
	public String stdName;
	public String stdId;
	public String address;
}


class Deserialization implements Serializable{
	public String stdName;
	public String stdId;
	public String address;
	
	void stdDetails() {
		System.out.println("Student name : " + stdName);
		System.out.println("Student ID : " + stdId);
		System.out.println("Student Address : " + address);
	}
	
}


public class TestSerialization {
	
	public static void main(String[] args) {
		
		//Serialization
		Serialization sl = new Serialization();
		sl.stdName = "Rohit";
		sl.stdId = "S012";
		sl.address = "Kolkata";
		
		try {
			FileOutputStream fileOut = new FileOutputStream("student.txt");
			ObjectOutputStream objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(sl);
			objOut.close();
			fileOut.close();	
			System.out.println("Student object data is written on student.txt");
		}catch (IOException i) {
			i.printStackTrace();
			System.out.println("IO Exception happen");
		}

		
		//Deserialization
		Deserialization deSl = new Deserialization();
		
		try {
			FileInputStream fileIn = new FileInputStream("student.txt");
			ObjectInputStream objIn = new ObjectInputStream(fileIn);
			deSl =  (Deserialization) objIn.readObject();   //runtime exception 
			objIn.close();
			fileIn.close();
			System.out.println("Object data retrieved from student.txt");
		} catch (IOException | ClassNotFoundException e) {
			System.out.println("student data does not found.");
			e.printStackTrace();
		}
		deSl.stdDetails();
		
		
	}
}
	
