package com.objectorientations;

public class AccessModifierOthers {	
	public static void main(String[] args) {
		

	}
}

class A{
	 int i = 0;
	 void method() {
	}
}

class B{
	strictfp class C{	
		
	}
}

/*
 * For Outer classes - only public, abstract & final are permitted
 * For Inner classes - only public, protected, private, abstract, static & 
 * 					   final are permitted
 * For Methods - static, final, abstract, native, synchronized, strictfp
 * For Variables - static, final, volatile, transient, strictfp
 */
