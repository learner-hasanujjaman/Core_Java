package com.objectorientations;



public class MainFromOtherMainMethod {
	
	/*
	 * while trying to access main methods of other classes, we must provide 
	 * String array as parameter.
	 * 
	 * Arguments can be --- 
	 * 		1. args - that indicates towards command line arguments
	 * 		2. user defined arguments
	 */
	
	public static void main(String[] args) {
		System.out.println("calling main method ");
		
		
		TestMain.main(args); 
		
		String[] arguments = {"abc", "def", "ghi"};
		TestMain.main(arguments);
	}
	

}
