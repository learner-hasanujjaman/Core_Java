package com.objectorientations;

//import java.lang.Thread.*;  -- importing this will not resolve compilation problem
import static java.lang.Thread.*;  // static import resolves the issue 
import static java.lang.System.*;

public class Static_Import {
	
	public void accessStaticVars() {
		
		/*
		 * Thread class - 
		 * 	public static final int MIN_PRIORITY
		 * 	public static final int NORM_PRIORITY
		 * 	public static final int MAX_PRIORITY
		 * 
		 * System class - 
		 * 	public static final PrintStream out 
		 * If we import this, can use out.println() directly
		 */
		
		//Accesing without any reference var or class name - compilation error
//		System.out.println(MIN_PRIORITY);
//		System.out.println(NORM_PRIORITY);
//		System.out.println(MAX_PRIORITY);
		
		//Accessing using class name only 
		System.out.println("Accessing using class name as they are static --");
		System.out.println(Thread.MIN_PRIORITY);
		System.out.println(Thread.NORM_PRIORITY);
		System.out.println(Thread.MAX_PRIORITY);
		
		
		//Accessing after importing static vars from Thread
		System.out.println("Accessing after importing static vars from Thread --");
		System.out.println(MIN_PRIORITY);
		System.out.println(NORM_PRIORITY);
		System.out.println(MAX_PRIORITY);
	}
	
	public void printStmtDirect() {
		out.println("printing directly");
	}

	public static void main(String[] args) {
		Static_Import st = new Static_Import();
		st.accessStaticVars();
	}

}
