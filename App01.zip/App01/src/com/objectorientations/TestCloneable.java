package com.objectorientations;


/*
 * Object with a class that implements Cloneable interface is only eligible for cloning 
 * clone() method --> already defined in Object class
 * Check TestNotCloneabe class in this package to view how "CloneNotSupportedException" works
 */

class Player implements Cloneable{
	String name;
	int jourseyNo;
	String team;
	
	Player(String name, int jourseyNo, String team){
		this.name = name;
		this.jourseyNo = jourseyNo;
		this.team = team;
	}
	
	public void getPlayerDetails() {
		System.out.println("Player name : " + this.name);
		System.out.println("Player roll : " + this.jourseyNo);
		System.out.println("Player team : " + this.team);
	}
	public Object clone() throws CloneNotSupportedException {
		//obj --> Object class clone() method
		Object obj = super.clone(); 
		return obj;	
	}	
}

class Play {
	String name;
	int jourseyNo;
	String team;
	
	Play(String name, int jourseyNo, String team){
		this.name = name;
		this.jourseyNo = jourseyNo;
		this.team = team;
	}
}

public class TestCloneable {

	public static void main(String[] args) {
		
		try {
			Player player1 = new Player("Rohit",45, "India");
			Object obj1 = player1.clone();
			Player dupPlayer1 = (Player) obj1;			
			dupPlayer1.getPlayerDetails();
			System.out.println();
			
			Player player2 = new Player("Virat",18, "India");
			Object obj2 = player2.clone();
			Player dupPlayer2 = (Player) obj2;
			dupPlayer2.getPlayerDetails();
			System.out.println();
			
			Play pl = new Play("Bob", 0, "World");
//			Object obj3 = pl.clone();
			//The method clone() from the type Object is not visible
			//we can't clone this object as original class of it is not implementing Clonable 
			

			
		} catch (CloneNotSupportedException e) {
			System.out.println("Clone does not supported.");
			e.printStackTrace();
		}
		

	}

}
