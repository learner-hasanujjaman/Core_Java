package com.objectorientations;

class Class1{
	static
	{
		System.out.println("class loading...");
	}
	Class1(){
		System.out.println("object creating...");
	}
}

public class ForName_Class {
	public static void main(String[] args) {
//		Class1 cs1 = new Class1();
		/*
		 * by above instance - 
		 * 1. class byte code loaded
		 * 2. object created
		 */
		
		
		/*
		 * Class.forName("String s") - loads byte code of the class to memory(method
		 *    area) without creating an object
		 */
		try {
			Class c = Class.forName("com.objectorientations.Class1");
			System.out.println(c.getName());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}

}
