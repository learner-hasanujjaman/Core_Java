package com.objectorientations;

class A1{
	void print() {
		System.out.println("inside A1 class");
	}
	@Override
	public String toString() {
		return "user defined toString() method";
	}
}

class A2{
	void print() {
		System.out.println("inside A2 class");
	}
}

public class HashCodeToStringMethods {
	
	public static void main(String[] args) {
		A1 a = new A1();
		System.out.println("hashcode : "+a.hashCode());
		System.out.println("full_class_name@reference_variable : "+a.toString());
		
		A2 b = new A2();
		System.out.println("hashcode : "+b.hashCode());
		System.out.println("full_class_name@reference_variable : "+b.toString());
		
		
		System.out.println();
		System.out.println(b);
		System.out.println(a);
		
	}

}


