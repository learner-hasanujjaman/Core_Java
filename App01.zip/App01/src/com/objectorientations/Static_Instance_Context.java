package com.objectorientations;

public class Static_Instance_Context {
	
	//static context
	static
	{
		System.out.println("static block");
	}
	static int i = m1();
	static int m1() {
		System.out.println("static method");
		return 1;
	}
	
	//instance context
	{
		System.out.println("instance block");
	}
    int j = m2();
	int m2() {
		System.out.println("instance method");
		return 1;
	}
	
	Static_Instance_Context() {
		System.out.println("Constructor");
	}
	
	
	

	public static void main(String[] args) {
		Static_Instance_Context st = new Static_Instance_Context();
		
		System.out.println("-------------------");
		Static_Instance_Context st2 = new Static_Instance_Context();
		
		System.out.println("-------------------");
		Static_Instance_Context st3 = new Static_Instance_Context();
		
	}
	/*
	 * static context - only saved one time in the memory
	 * instance context - saved every time an object is created
	 */

}
