package com.objectorientations;

public enum Enum1 {
	/*
	 * * enum - mainly used to specify constant values
	 * * all constant are by default -> public static final
	 * * enum can be - variable
	 * 			   - method
	 * 			   - class
	 * * return same type by default if not constructors manipulation happens
	 * * displays variable name directly
	 */
	
	A, B, C;
	
	public static void main(String[] args) {
		System.out.println(Enum1.A);
		System.out.println(Enum1.B);
		System.out.println(Enum1.C);
		
		System.out.println(Enum1.A.getClass().getSimpleName());
		System.out.println(Enum1.C.getClass().getSimpleName());
		
	}
	
}


