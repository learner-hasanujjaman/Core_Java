package com.objectorientations;

 interface Interface1 {
	 /*
	void m1() {
		System.out.println("m1 - concrete method in class A(parent)");
	}
	
	---> throws compilation error as concrete methods are not allowed inside Interfaces
		 By default all methods -> public abstract
		 			all variables -> public static final
		 No need to specify using keywords
	*/
	 
	int P = 45;   //public static final
	void m1(int a);
	void m2();
	void m3();
}


class ImplementClass1 implements Interface1 {
	
	/*
	 * every method should be 'public' as overriding methods are by default public
	 * and overridden methods must be of same or higher visibility
	 */
	@Override
	public void m1(int j) {
		System.out.println("m1 - "+ j);
	}
	
	@Override
	public void m2() {
		System.out.println("m2 - overriden method");
	}

	@Override
	public void m3() {
		System.out.println("m3 - overriden method");
	}	
	
	void m4() {
		System.out.println("m4 - concrete method");
	}
}




public class InterfaceBasic {
	

	public static void main(String[] args) {
		//way 1
//		Interface1 in = new Interface1(); --->error as object creation of interface is not allowed		
		Interface1 a = new ImplementClass1();
		a.m1(5);
		a.m2();
		a.m3();
//		a.m4();  ---> error | 
		//can't access implement class's own elements as initiated with parent class reference
		
		ImplementClass1 b = new ImplementClass1();
		b.m1(13);
		b.m2();
		b.m3();
		b.m4();
		
		
		
		System.out.println("Accessing the final value ------");
		System.out.println(Interface1.P);
		System.out.println(a.P);  //suggested to use interfaceName.P
		System.out.println(ImplementClass1.P);
		System.out.println(b.P);  //suggested to use interfaceName.P

//		Interface1.P = 44; -->error, P is final field, so can't change the value
		
	}

}
