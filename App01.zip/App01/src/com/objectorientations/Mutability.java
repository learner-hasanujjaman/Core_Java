package com.objectorientations;

public class Mutability {
	public void mutableCode() {
		/*
		 * String - Mutable object
		 * once memory is allocated, can't be altered - means can't be modified the same
		 * object. Every time we modified something, will create a new object and 
		 * assign new value to it
		 * Not Thread-safe -> can't access the string from multiple threads 
		 * 					simultaneously, need synchronization 
		 */
		String str1 = "Nil ";
		String str2 = str1.concat("Nitin ");
		String str3 = str1.concat("Mukesh ");
		
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str3);
		System.out.println(str1.hashCode());
		System.out.println(str2.hashCode());
		System.out.println(str3.hashCode());
		
		String str4 = "new member string";
//		str4.split(" ");
		System.out.println("splitted string --");
		System.out.println(str4.split(" "));   //--> pointing to the class
		
		/*
		 * Split() will split the string on basis of regex provided and store them 
		 * in a list of Strings
		 * So, String is not changing itself, rather creating a new object and storing 
		 * the values
		 */
	}
	
	public void imMutableCode() {
		System.out.println("-----------------------");
		/*
		 * StringBuffer immutable string, default size is 16 chars
		 * size increases as we add many characters -
		 * Memory allocations - similar ArrayList
		 * does not create new objects while we modify the string
		 * Thread-safe -> can access the string from multiple threads simultaneously 
		 */
		StringBuffer sb = new StringBuffer();
		
		StringBuffer sb1 = sb.append("Nil ");
		StringBuffer sb2 = sb.append("Nitin ");
		StringBuffer sb3 = sb.append("Mukesh ");
		
	
		System.out.println(sb1);
		System.out.println(sb2);
		System.out.println(sb3);
		System.out.println(sb1.hashCode());
		System.out.println(sb2.hashCode());
		System.out.println(sb3.hashCode());
		
		
		
		//check max size
		System.out.println(sb.capacity());
		

		
	}

	public static void main(String[] args) {
		Mutability mt = new Mutability();
		mt.mutableCode();
		mt.imMutableCode();

	}

}
