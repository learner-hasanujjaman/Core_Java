package com.objectorientations;

import com.objectorientations.multipleclasses.Student;
/*
 * need this import statement as Student class is residing in some other package
 */

public class AccessStudentClass {
	
	class NewStudent extends Student{
		//getStudentDetails() method of Student class will be available 
	}

	public static void main(String[] args) {
		//way 1
		Student std = new Student();
		std.getStudentDetails();
		
		
		//way2
		AccessStudentClass accStd= new AccessStudentClass();
		AccessStudentClass.NewStudent st= accStd.new NewStudent();
		
		st.getStudentDetails();
		
	}

}
