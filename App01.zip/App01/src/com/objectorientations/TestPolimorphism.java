package com.objectorientations;

public class TestPolimorphism {
	
	public static void main(String[] args) {
    	Polimorphism1 pol1 = new Polimorphism1();
    	pol1.m1();  //calling super-class method
    	
    	Polimorphism2 pol2 = new Polimorphism2();
    	pol2.m1();  //calling sub-class method
    	
    	Polimorphism1 pol3 = new Polimorphism2();
    	pol3.m1();  // overriden method m1()

	}
}
