package com.objectorientations;


class Account2{
	String accNo;
	String accHolder;
	String accType;
	int balance;
	
	public Account2(String accNo, String accHolder, String accType, int balance) {
		this.accNo = accNo;
		this.accHolder = accHolder;
		this.accType = accType;
		this.balance = balance;
	}
}

class Employee2 implements Cloneable{
	String eId;
	String eName;
	float eSal;
	
	Account2 acc;
	
	public Employee2(String eId, String eName, float eSal, Account2 acc) {
		this.eId = eId;
		this.eName = eName;
		this.eSal = eSal;
		this.acc = acc;
	}
	
	public void eDetails () {
		System.out.println("Employee id : " + this.eId);
		System.out.println("Employee name : " + this.eName);
		System.out.println("Employee salary : " + this.eSal);
		System.out.println("Employee account No : " + this.acc.accNo);
		System.out.println("Employee balance : " + this.acc.balance);
	}
	
	//For Deep cloning - developer has to implement cloning logic
	public Object clone() throws CloneNotSupportedException{
		Account2 account = new Account2(acc.accNo, acc.accHolder, acc.accType, acc.balance);
		Employee2 emp = new Employee2(this.eId, this.eName, this.eSal, account);
		return emp;
	}	
}

public class TestDeepCloning {

	public static void main(String[] args) throws CloneNotSupportedException {
		Account2 acc = new Account2("123678", "Rohit", "Savings", 150000);
		
		Employee2 emp = new Employee2("101", "Rohit", 50000, acc);
		
		Object obj = emp.clone();
		Employee2 dupEmp = (Employee2) obj;
		
		dupEmp.eDetails();
		System.out.println();
		
		System.out.println("Employee object referance val : " + emp);
		System.out.println("Duplicate Employee object referance val : " + dupEmp);
		System.out.println("Account object referance val in Employee: " + emp.acc);
		System.out.println("Account object referance val in Duplicate Employee: " + dupEmp.acc);
		
		/*
		 * emp and dupEmp --> pointing towards two different objects
		 * 
		 * acc --> is pointing towards two different objects
		 * 
		 * In Deep cloning, both container  and contained objects get cloned 
		 * No default method present, dev has to implement cloning logic in clone() method
		 */

	}

}
