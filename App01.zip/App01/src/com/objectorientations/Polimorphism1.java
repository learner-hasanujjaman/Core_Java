package com.objectorientations;

class Polimorphism1 {
	void m1() {
		System.out.println("super class method");
	}
}
class Polimorphism2 extends Polimorphism1 {
	void m1() {
		System.out.println("sub class method");
	}

}


