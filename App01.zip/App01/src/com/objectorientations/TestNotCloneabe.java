package com.objectorientations;

class T {
	String name;
	int jourseyNo;
	String team;
	
	T(String name, int jourseyNo, String team){
		this.name = name;
		this.jourseyNo = jourseyNo;
		this.team = team;
	}
	public void getPlayerDetails() {
		System.out.println("Player name : " + this.name);
		System.out.println("Player roll : " + this.jourseyNo);
		System.out.println("Player team : " + this.team);
	}
	public Object clone() throws CloneNotSupportedException {
		Object obj = super.clone();
		return obj;
		
	}
}

public class TestNotCloneabe {

	public static void main(String[] args) throws CloneNotSupportedException {
		T t = new T("Rohit",45, "India");
		Object obj1 = t.clone();
		T dupT1 = (T) obj1;			
		dupT1.getPlayerDetails();
		System.out.println();

	}
	
	/*
	 * Throwing "java.lang.CloneNotSupportedException: com.objectorientations.T" exception as 
	 * T class does not impletemts Cloneable interface
	 */

}
