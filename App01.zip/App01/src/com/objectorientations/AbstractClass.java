package com.objectorientations;


abstract class AbstractClass1 {
	public void m1() {
		System.out.println("m1 - concrete method in class A(parent)");
	}
	abstract void m2();
	abstract void m3();
}


class ChildAbsClass extends AbstractClass1{
	
	@Override
	void m2() {
		System.out.println("m2 - overriden method in class B(child)");
	}

	@Override
	void m3() {
		System.out.println("m3 - overriden method in class B(child)");
	}	
	
	void m4() {
		System.out.println("m4 - concrete method in class B(child)");
	}
}


public class AbstractClass {

	public static void main(String[] args) {
		//way 1
//		A a = new A(); ---> error as object creation of abstract class is not allowed		
		AbstractClass1 a = new ChildAbsClass();
		a.m1();
		a.m2();
		a.m3();
//		a.m4();  ---> error | can't access child classes own elements as initiated with parent class reference
		
		ChildAbsClass b = new ChildAbsClass();
		b.m1();
		b.m2();
		b.m3();
		b.m4();

	}

}
