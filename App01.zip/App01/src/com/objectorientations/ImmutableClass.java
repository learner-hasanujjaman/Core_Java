package com.objectorientations;

final class Calculator{
	/*
	 * Calculator - user defined Immutable class (Built-in --> String)
	 * no attribute can be changed from outside or child class(private | final | no setter())
	 * Every time performs some operation, creates a new object 
	 * old object remains intact
	 * 
	 */
	private final int count;
	
	public Calculator(int count) {
		this.count=count;
	}
	
	public int getCount() {
		return this.count;
	}
	
	public Calculator increase(int val) {
		Calculator cal = new Calculator(this.count+val);
		return cal;
	}
	
	public Calculator decrease(int val) {
		Calculator cal = new Calculator(this.count-val);
		return cal;
	}
		
}



public class ImmutableClass {

	public static void main(String[] args) {
		int val = 40;
		Calculator cal = new Calculator(val);
		System.out.println(cal.getCount());
		
		Calculator cal1 = cal.increase(20);   //40+10
		System.out.println(cal1.getCount());
		
		Calculator cal2 = cal.decrease(10);   //40-10
		System.out.println(cal2.getCount());
		
		
		System.out.println("increasing and decreasing count values ------");
		cal.increase(20);   
		System.out.println(cal.getCount());
		
		cal.decrease(10);   
		System.out.println(cal.getCount());
		
		//no change, as no effect on old class object
		// changed values are assinged to new objects
	}

}
