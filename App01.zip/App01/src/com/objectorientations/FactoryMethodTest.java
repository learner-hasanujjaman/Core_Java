package com.objectorientations;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.ResourceBundle;

public class FactoryMethodTest {

	public static void main(String[] args) throws ClassNotFoundException {
		FactoryMethod fm = FactoryMethod.refObj();
		fm.method();
		
		/*
		 * as private constructor is called internally, we can see it 
		 * in output
		 */
		
		//Static Factory Method - methods that returns static objects
		Class c = Class.forName("com.objectorientations.FactoryMethodTest");
		
		NumberFormat nf = NumberFormat.getInstance();
		System.out.println(nf.toString());
		
		DateFormat df = DateFormat.getInstance();
		System.out.println(DateFormat.DAY_OF_WEEK_FIELD);
		
//		ResourceBundle rb = ResourceBundle.getBundle("com.objectorientations.FactoryMethodTest");
//		System.out.println(rb.getBaseBundleName()); //error as no bundle is placed in above class
		
		
		
		// Instance Factory Method - methods that returns
		
		String str = new String("new adda ");
		String str1 = str.concat("hebbi");
		System.out.println(str1);
		String str2 = str.trim();
		System.out.println(str2);
	}

}
