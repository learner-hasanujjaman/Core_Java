package com.objectorientations;

class A11{
	void m() {
		System.out.println("Class A");
	}
}

class B111 extends A11{
	void m() {
		System.out.println("Class B");
	}
}

class C{
	void m() {
		System.out.println("Class C");
	}
}

public class TestInstanceof {

	public static void main(String[] args) {
		A11 a = new A11();
		B111 b = new B111();
		A11 a1 = new B111();
		C c = new C();
		
		System.out.println(a instanceof A11);
		System.out.println(b instanceof B111);
		System.out.println(b instanceof A11);
		System.out.println(a1 instanceof A11);
		System.out.println(a1 instanceof B111);
		System.out.println(a instanceof B111);
//		System.out.println(a instanceof C); --> compilation error as both classes are not related
		
		

	}

}
