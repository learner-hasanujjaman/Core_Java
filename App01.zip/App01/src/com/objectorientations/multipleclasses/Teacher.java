package com.objectorientations.multipleclasses;

public class Teacher {
	String teacherId = "T-11";
	String teacherName = "Abinash Sinha";
	String phoneNo = "8923345665";
	String section = "";
	
	public void getStudentDetails() {
		System.out.println("Teacher details ----------");
		System.out.println("Teacher Name : "+ teacherName);
		System.out.println("Teacher Id : "+ teacherId);
		System.out.println("Phone Number : "+ phoneNo);
	}
	

}
