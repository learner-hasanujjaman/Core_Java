package com.objectorientations.multipleclasses;

public class Student extends Teacher {

	int rollNo = 4;
	String stdName = "Suhash Chaturvedi";
	String cls = "5th";
	String section = "B";
	
	public void getStudentDetails() {
		System.out.println("Student details ----------");
		System.out.println("Student Name : "+ stdName);
		System.out.println("Student Roll Number : "+ rollNo);
		System.out.printf("Student is in : %s grade %s section\n", cls, section);
		
	}
	
}
