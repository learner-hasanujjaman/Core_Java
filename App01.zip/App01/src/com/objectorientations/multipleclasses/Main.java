package com.objectorientations.multipleclasses;

public class Main {

	public static void main(String[] args) {
		Student student = new Student();
		
		student.getStudentDetails();
		System.out.println("Location of the class - "+ student.getClass());
		
		
		Teacher teacher = new Teacher();
		teacher.getStudentDetails();
		System.out.println("Location of the class - "+ teacher.getClass());
		
	}

}
