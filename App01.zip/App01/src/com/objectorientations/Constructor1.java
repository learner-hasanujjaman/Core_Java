package com.objectorientations;

class NewConstructor {
	int i=0;
	 NewConstructor(int j){
		this.i = j;
	}
	
//	Const(){
//	}
}

class InstanceFirst{
	/*
	 * instance variable (i,j) will be executed before executing the constructor.
	 * if multiple instances are present, they will be executed as per the order
	 * of appearance
	 * similar for instance blocks
	 */
	//instance variables
	int i = m1(), j = m2();
	
	//instance blocks
	{
		System.out.println("1st instance block");
	}
	{
		System.out.println("2nd instance block");
	}
	
	
	InstanceFirst(){
		System.out.println("constractor!");
	}
	public int m1() {
		System.out.println("m1 method!");
		return 12;
	}
	public int m2() {
		System.out.println("m2 method!");
		return 12;
	}
}

public class Constructor1 {
	
	public static void main(String[] args) {
		NewConstructor nc = new NewConstructor(10);
		System.out.println(nc.i);
		
//		Const c = new Const();
		
		InstanceFirst inf = new InstanceFirst();
		inf.m1();
	}

}
