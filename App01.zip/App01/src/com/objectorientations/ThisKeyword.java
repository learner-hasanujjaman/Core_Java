package com.objectorientations;

public class ThisKeyword {
	
	/*
	 * Constructor chaining - calling a constructor from other constructors in the same
	 * class using this keyword
	 * 
	 * Conditions:
	 * 1. 'this' keyword (constructor calling) must be the first line 
	 * 		-- that means, only one constructor can be called from one constructor
	 * 2. constructor calling using 'this' keyword is only possible from Constructors
	 * 		and not from methods
	 */
	
	int i = 9;
	int j = 23;
	ThisKeyword(){
		this("key");
		System.out.println("parameterless constructor!");
	}
	
	ThisKeyword(int i, int j){
		this();
//		this("key");
		System.out.println("local variables - "+ i + " "+j);
		System.out.println("class level variables - "+ this.i + " "+this.j);
		
//		this();
	}
	ThisKeyword(String str){
		System.out.println("String constructor");
	}
	
	public void method1() {
//		this();
		/*
		 * Above line will cause compilation error as Constructor calling using this()
		 * keyword only permissible from Constructors only and not from methods
		 */
	}
	
	
	

	public static void main(String[] args) {
		ThisKeyword tk = new ThisKeyword(12,33);
		
	}

}
