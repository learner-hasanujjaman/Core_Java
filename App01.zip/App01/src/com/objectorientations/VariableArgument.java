package com.objectorientations;

import java.util.Arrays;

class VarArg{
	/*
	 * 1. Variable Argument Methods - variable number of arguments 
	 * 	  It stores all the arguments as an array of same data type
	 * 
	 * 2. Can't provide multiple variable arguments in one method
	 *    ---> error; "Variable argument should be the last parameter of any method"
	 *    
	 * 3. Can provide multiple arguments along with the variable argument, 
	 * 	  but the variable argument must be the last parameter
	 */
	public void method1(int ... nums) {
		System.out.println("Array size : "+nums.length);
		System.out.println(Arrays.toString(nums));
		
	}
	
//	public void method2(int ... ns, String ... str) {
//		System.out.println("Array size : "+ns.length);
//		System.out.println(Arrays.toString(ns));
//		
//	}
}

public class VariableArgument {

	public static void main(String[] args) {
		VarArg var = new VarArg();
		var.method1();
		var.method1(23);
		var.method1(233,3,45);
		var.method1(10,20,30,40);
		var.method1(10,20,30,40,50,60,70,80);
		
	}

}
