package com.objectorientations;

public class FactoryMethod {
	
	private FactoryMethod() {
		System.out.println("private constructor");
	}
	void method() {
		System.out.println("non-static method1");
	}
	
	static FactoryMethod refObj() {
		FactoryMethod fm = new FactoryMethod();
		return fm;
	}
	
	

}
// Calling above method in FactoryMethodTest class.

//		FactoryMethod fm = new FactoryMethod(); -- constructor not visible
		
//		Class c = Class.forName("com.objectorientations.FactoryMethod");
//		Object obj = c.newInstance();

		/*
		 * can't use above approach too as we need non-private and parameterless 
		 * constructors to be called by newInstance(), which is not present here
		 */
		
		/*
		 * This is a Design Pattern problem, use Factory Method (a method that returns an 
		 * object) to return an object of the class and make the method 'static'. 
		 * Accessible by class name.
		 
		
		//access the factory method to create an object
		FactoryMethod fm = FactoryMethod.refObj();
		fm.method();
		
		
		Types:
		1. Static Factory Method - methods that returns static objects
		1. Instance Factory Method - methods that returns instance objects
		*/
					

