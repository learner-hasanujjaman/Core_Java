package com.objectorientations;


class Account1{
	String accNo;
	String accHolder;
	String accType;
	int balance;
	
	public Account1(String accNo, String accHolder, String accType, int balance) {
		this.accNo = accNo;
		this.accHolder = accHolder;
		this.accType = accType;
		this.balance = balance;
	}
}

class Employee1 implements Cloneable{
	String eId;
	String eName;
	float eSal;
	
	Account1 acc;
	
	public Employee1(String eId, String eName, float eSal, Account1 acc) {
		this.eId = eId;
		this.eName = eName;
		this.eSal = eSal;
		this.acc = acc;
	}
	
	public void eDetails () {
		System.out.println("Employee id : " + this.eId);
		System.out.println("Employee name : " + this.eName);
		System.out.println("Employee salary : " + this.eSal);
		System.out.println("Employee balance : " + this.acc.balance);
	}
	
	//Object class clone method utilizing
	public Object clone() throws CloneNotSupportedException{
		Object obj = super.clone();
		return obj;
	}	
}



public class TestShallowCloning {

	public static void main(String[] args) throws CloneNotSupportedException {
		Account1 acc = new Account1("123678", "Rohit", "Savings", 150000);
		
		Employee1 emp = new Employee1("101", "Rohit", 50000, acc);
		
		Object obj = emp.clone();
		Employee1 dupEmp = (Employee1) obj;
		
		dupEmp.eDetails();
		System.out.println();
		
		System.out.println("Employee object referance val : " + emp);
		System.out.println("Duplicate Employee object referance val : " + dupEmp);
		System.out.println("Account object referance val in Employee: " + emp.acc);
		System.out.println("Account object referance val in Duplicate Employee: " + dupEmp.acc);
		
		/*
		 * emp and dupEmp --> pointing towards two different objects 
		 * 
		 * acc --> is pointing towards the same object 
		 * 
		 * In Shallow cloning only container object gets cloned not contained class as 
		 * cloning is performed in container class
		 * Default method present in Object class, no need to implement new cloning logic 
		 */

	}

}
