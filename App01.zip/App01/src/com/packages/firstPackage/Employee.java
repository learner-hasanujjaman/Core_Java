package com.packages.firstPackage;

/*
 * While writing a package, create class as public as it meant to be 
 * accessed outside
 */
public class Employee {
	String empId;
	String empName;
	String empSal;
	String empEmail;
	
	Employee(String empId,String empName,String empSal,String empEmail){
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empEmail = empEmail;
	}
	
	public void empDetails() {
		System.out.println("Employee Id : " + empId);
		System.out.println("Employee name : " + empName);
		System.out.println("Employee salary : " + empSal);
		System.out.println("Employee email : " + empEmail);
	}
}
