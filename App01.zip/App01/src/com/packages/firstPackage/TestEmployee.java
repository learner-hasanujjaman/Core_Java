package com.packages.firstPackage;

/*
 * import com.packages.firstPackage; -> need this if Emoloyee.java resides in 
 * some other package
 */

public class TestEmployee {

	public static void main(String[] args) {
		System.out.println("TestEmployee.java");
		Employee emp = new Employee("E101", "Salvador Dali", "50000","sal.dali@gmail.com");
		emp.empDetails();
	}

}
