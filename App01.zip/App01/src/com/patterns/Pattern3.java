package com.patterns;

public class Pattern3 {
	
	public void pattern1() {
		for(int i=1; i<=10; i++) {
			for(int j=1; j<=10; j++) {
				if(j>=11-i) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
		
	public void pattern2() {
		for(int i=1; i<=10; i++) {
			for(int j=1; j<=10-i; j++) {
				System.out.print(" ");
			}
			for(int k=1; k<=i; k++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public void pattern3() {
		for(int i=1; i<=10; i++) {
			for(int j=1; j<=10-i; j++) {
				System.out.print(" ");
			}
			for(int k=1; k<=i; k++) {
				System.out.print(k);
			}
			System.out.println();
		}
	}
	
	public void pattern4() {
		//pyramid shaped *s
		for(int i=1; i<=10; i++) {
			for(int j=1; j<=10-i; j++) {
				System.out.print(" ");
			}
			for(int k=1; k<=i; k++) {
				System.out.print("* ");
			}
			System.out.println();
		}
	}
	
	public void pattern5() {
		//pyramid shaped *s
		for(int i=1; i<=10; i++) {
			for(int j=1; j<=10-i; j++) {
				System.out.print(" ");
			}
			for(int k=1; k<=i; k++) {
				System.out.print("* ");		
//				System.out.print(k+" ");              //numbers in place of *
//				System.out.print((char)(64+k)+" ");   //letters in place of *
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Pattern3 pt = new Pattern3();
		
//		pt.pattern1();
//		pt.pattern2();
		//pattern1() and pattern2() gives same result
		pt.pattern3();
		pt.pattern4();
		pt.pattern5();

	}

}
