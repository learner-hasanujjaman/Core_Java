package com.patterns;

public class Pattern2 {
	
	public void pattern1() {
		for (int i=1; i<=10; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public void pattern2() {
		for (int i=1; i<=10; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print(j);
			}
			System.out.println();
		}
	}
	
	public void pattern3() {
		for (int i=1; i<=10; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print(i+"  ");
			}
			System.out.println();
		}
	}
	
	public void pattern4() {
		for (int i=1; i<=10; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print((char)(64+j)+" ");
			}
			System.out.println();
		}
	}
	
	public void pattern5() {
		for (int i=1; i<=10; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print((char)(64+i)+" "); //using ascii value 65->A
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Pattern2 pt = new Pattern2();
		
		pt.pattern1();
		pt.pattern2();
		pt.pattern3();
		pt.pattern4();
		pt.pattern5();

	}

}
