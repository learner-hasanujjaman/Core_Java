package com.patterns;

public class Pattern5 {
	
	public void pattern1() {
		
		/*
		 *      * 
			   * * 
			  * * * 
			 * * * * 
			* * * * * 
			 * * * * 
			  * * * 
			   * * 
			    * 
		 */
		
		int a = 10;
		for(int i=1; i<=a; i++) {
			for(int j=1; j<=a-i; j++) {
				System.out.print(" ");
			}
			for(int k=1; k<=i; k++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		
		for(int p=1; p<=a; p++) {
			for(int m=1; m<=p; m++) {
				System.out.print(" ");
			}
			for(int n=1; n<=a-p; n++) {
				System.out.print("* ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Pattern5 pt = new Pattern5();
		
		pt.pattern1();

	}

}
