package com.patterns;

public class Pattern1 {
	
	public void pattern1() {
		for(int i=1; i<=10; i++) {
			for(int j=1; j<=10; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public void pattern2() {
		for(int i=1; i<=10; i++) {
			for(int j=1; j<=10; j++) {
				System.out.print(j+" ");
			}
			System.out.println();
		}
	}
	
	public void pattern3() {
		for(int i=1; i<=10; i++) {
			for(int j=1; j<=10; j++) {
				System.out.print(i+" ");
			}
			System.out.println();
		}
	}
	
	public void pattern4() {
		/*
		String str = "abcdefghijklmnopqrstuvwxyz";
		for(int i=0; i<10; i++) {
			for(int j=0; j<10; j++) {
				System.out.print(str.toUpperCase().charAt(j)+" ");
			}
			System.out.println();
		}
		*/
		for(int i=1; i<=10; i++) {
			for(int j=1; j<=10; j++) {
				System.out.print((char)(64+j)+" ");    //accessing ascii characters
			}
			System.out.println();
		}
		
	}
	public void pattern5() {
		for(int i=1; i<=10; i++) {
			for(int j=1; j<=10; j++) {
				System.out.print((char)(64+i)+" ");    //accessing ascii characters
			}
			System.out.println();
		}
		
	}
	
	//reverse patterns
	
	public void pattern6() {
//		for(int i=10; i>0; i--) {
//			for(int j=i; j>0; j--) {
//				System.out.print("*");  
//			}
//			System.out.println();
//		}
		for(int i=0; i<10; i++) {
			for(int j=10-i; j>0; j--) {
				System.out.print("*");  
			}
			System.out.println();
		}
		//both will work
	}
	
	public void pattern7() {
		for(int i=1; i<=10; i++) {
			for(int j=1; j<=11-i; j++) {
				System.out.print(j+" ");  
			}
			System.out.println();
		}
	}
	
	public void pattern8() {
		for(int i=1; i<=10; i++) {
			for(int j=1; j<=11-i; j++) {
				System.out.print(i+" ");  
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Pattern1 pt = new Pattern1();
		pt.pattern1();
		pt.pattern2();
		pt.pattern3();
		pt.pattern4();
		pt.pattern5();
		pt.pattern6();
		pt.pattern7();
		pt.pattern8();

	}

}
