package com.patterns;

public class PatternGFG {
	
	//https://www.geeksforgeeks.org/java-pattern-programs/
	
	public void squareStar() {
		int n=5;
		int i,j;
		for(i=0; i<n; i++) {
			for(j=0; j<n; j++) {
				//print * if position is first or last column/row
				if(i==0 || j==0 || i==n-1 || j==n-1) {
					System.out.print("*");
				}else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
	
	

	public static void main(String[] args) {
		PatternGFG pt = new PatternGFG();
		
		pt.squareStar();
		

	}

}
