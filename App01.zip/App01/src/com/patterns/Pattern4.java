package com.patterns;

public class Pattern4 {
	
	public void pattern1() {
		/* even number of *s in each rows	
		 *      **
			   ****
			  ******
			 ********
			**********
		 */
		
		for(int i=1; i<=5; i++) {
			for(int j=1; j<=5-i; j++) {
				System.out.print(" ");
			}
			for(int k=1; k<=2*i; k++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public void pattern2() {
		/* even number of numbers
		 *     12
			  1234
			 123456
			12345678
		 */
		for(int i=1; i<=4; i++) {
			for(int j=1; j<=4-i; j++) {
				System.out.print(" ");
			}
			for(int k=1; k<=2*i; k++) {
				System.out.print(k);
			}
			System.out.println();
		}
	}
	
	public void pattern3() {
		/* odd number of *s in each rows	
		 *      *
			   ***
			  *****
			 *******
			*********

		 */
		for(int i=1; i<=5; i++) {
			for (int j=1; j<=5-i; j++) {
				System.out.print(" ");
			}
			for(int k=1; k<=(2*i-1); k++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	//printing patterns in reverse order
	public void pattern4() {
		for(int i=1; i<=5; i++) {
			for(int j=1; j<=i-1; j++) {
				System.out.print(" ");
			}
			for(int k=1; k<= 11-2*i; k++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public void pattern5() {
		for(int i=1; i<=5; i++) {
			for(int j=0; j<i-1; j++) {
				System.out.print(" ");
			}
			for(int k=1; k<10-(2*i-1); k++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public void pattern6() {
		for(int i=1; i<=10; i++) {
			for(int j=1; j<=i-1; j++) {
				System.out.print(" ");
			}
			for(int k=1; k<10-i; k++) {
				System.out.print("* ");
			}
			System.out.println();
		}
	}
	

	public static void main(String[] args) {
		Pattern4 pt = new Pattern4();
		
//		pt.pattern1();
//		pt.pattern2();
//		pt.pattern3();
		pt.pattern4();
//		pt.pattern5();
//		pt.pattern6();

	}

}
