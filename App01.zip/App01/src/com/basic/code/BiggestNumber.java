package com.basic.code;

import java.util.Scanner;

public class BiggestNumber {
	
	public int bigNum(int a, int b, int c) {
		
		int biggestNum = a;
		
		if(a==b & b==c) {
			return a;
		}
		
		if(biggestNum < b) {
			biggestNum = b;
		}
		
		if(biggestNum < c) {
			biggestNum = c;
		}
		
		return biggestNum;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter 3 numbers to compare - ");
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
		sc.close();
		
		BiggestNumber bg = new BiggestNumber();
		int bgNum = bg.bigNum(a, b, c);
		System.out.println(bgNum);
		

	}

}
