package com.basic.code;

public class Base {
	public int multiplication(int i, int j) {
		return i*j;
	}
	public int addition(int i, int j) {
		return i+j;
	}

	public static void main(String[] args) {
		Base b = new Base();
		int i = 52525;
		int j = 2424;
		int ans = b.multiplication(i, j);
		int ans2 = b.addition(i, j);
		
		System.out.println(ans);
		System.out.println(ans2);
		
	}

}
