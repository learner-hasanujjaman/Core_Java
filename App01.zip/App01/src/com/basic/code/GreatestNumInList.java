package com.basic.code;

import java.util.Arrays;

public class GreatestNumInList {
	
	public void greatestInList() {
		int[] numList = {23,3,4,44,32};
		Arrays.sort(numList);
		System.out.println(Arrays.toString(numList));
		System.out.println(numList[numList.length-1]);
		
		
	}
	
	public void reverseString() {
		String str = "new string";
		String revStr = "";
		for(int i=str.length()-1; i>=0; i--) {
			revStr += str.charAt(i);
		}
		System.out.println(revStr);
	}

	
	
	public static void main(String[] args) {
		GreatestNumInList grtInList = new GreatestNumInList();
		
		grtInList.greatestInList();
		grtInList.reverseString();

	}

}
