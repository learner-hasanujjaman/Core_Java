package com.basic.code;

public class InstanceCheck {

	public static void main(String[] args) {
		
		InstanceCheck ins = new InstanceCheck();
		System.out.println(ins instanceof InstanceCheck);
		// true as ins is an instance of class InstanceCheck
		
		
		

	}

}
