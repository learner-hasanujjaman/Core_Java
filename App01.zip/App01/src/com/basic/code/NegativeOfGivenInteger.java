package com.basic.code;

public class NegativeOfGivenInteger {

	public static void main(String[] args) {
		
		int x = 0;
		int y = 42;
		int z = -42;
		System.out.println(-Math.abs(x));
		System.out.println(-Math.abs(y));
		System.out.println(-Math.abs(z));
		

	}

}
