package com.innerClasses;

class A3{
	int i = 10;
	static String name = "Rabi";
	
	static class B3 {
		String sub = "B class attribute";
		void subM() {
			System.out.println("name : "+ name);
//			System.out.println("number : "+ i); --> can't access non-static members
		}
	}
}


public class StaticInnerClass {

	public static void main(String[] args) {
		A3.B3 ab = new A3.B3();
		System.out.println(ab.sub);
		ab.subM();

	}

}
