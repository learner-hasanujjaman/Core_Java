package com.innerClasses;

class A2{
	int i = 10;
	String name = "Rabi";
	
	void m() {
		// Method Local Inner Class - B2
		class B2 {
			String sub = "B class attribute";
			void subM() {
				System.out.println("name : "+ name);
				System.out.println("number : "+ i);
			}
		}
		B2 b = new B2();
		System.out.println(b.sub);
		b.subM();
		
	}
}

public class MethodLocalInnerClass {
	
	public static void main(String[] args) {
		A2 a = new A2();
		System.out.println(a.i);
		System.out.println(a.name);
		System.out.println();
		a.m();
	}
	

}
