package com.innerClasses;

//for abstract classes
abstract class A4{
	void m1() {
		System.out.println("A-m1");
	}
	abstract void m2();
	abstract void m3();
}

class C4{
	A4 a = new A4(){
		void m2() {
			System.out.println("C-m3");
		}
		void m3() {
			System.out.println("C-m3");
		}
	};
	
}


// for interfaces
interface I2{
	abstract void m1();
	abstract void m2();
}






public class AnnonymousInnerClass {

	public static void main(String[] args) {
		//abstract class
		System.out.println("printing with help of another class");
		C4 c = new C4();
		c.a.m1();
		c.a.m2();
		c.a.m2();
		
		System.out.println("printing without help of another class");
		A4 a = new A4(){
			void m2() {
				System.out.println("main-m3");
			}
			void m3() {
				System.out.println("main-m3");
			}
		};
		a.m1();
		a.m2();
		a.m2();
		
		System.out.println();
		//interface
		I2 i = new I2() {
			public void m1() {
				System.out.println("main-interface-m2");
			}
			public void m2() {
				System.out.println("main-interface-m3");
			}
		};
		i.m1();
		i.m2();
		//can take help of outer class too, same as classes
	}

}
