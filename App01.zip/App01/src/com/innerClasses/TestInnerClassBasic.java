package com.innerClasses;


class A1{
	int i = 10;
	void m1() {
		System.out.println("A1 -> m1()");
	}
	
	class B1{
		int j = 10;
		void m2() {
			System.out.println("B1 -> m2()");
			m1();
		}
		//accessing outer class var and methods
		int k = i +100;
//		m1(); --> not allowed
	}
}


public class TestInnerClassBasic {

	public static void main(String[] args) {
		//creating an object of an inner class
		A1 a = new A1();
		A1.B1 ab = a.new B1();
		System.out.println(ab.j);
		ab.m2();
		
		
		A1.B1 c = new A1().new B1();
		System.out.println(c.j);
		System.out.println(c.k);
		c.m2();
	}

}
