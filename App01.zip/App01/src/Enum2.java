import com.objectorientations.Enum1;

public enum Enum2 {
	//constant variables
		A, B(200), C("Robinhood");
		
		//instance variable
		int price;
		String name;
		
		Enum2() {
			System.out.println("inside parameterless constructor");
		}
		Enum2(int price) {
			this.price = price;
			System.out.println("inside constructor with int parameter");
		}

		Enum2(String name) {
			this.name = name;
			System.out.println("inside constructor with string parameter");
		}
		
		int getPrice() {
			return this.price;
		}
		String getName() {
			return this.name;
		}
		
		public static void main(String[] args) {
			System.out.println(Enum2.A);
			System.out.println(Enum2.B.getName()); //does not have a name - default value -> null
			System.out.println(Enum2.B.getPrice());
			System.out.println(Enum2.C.getName());
			System.out.println(Enum2.C.getPrice()); //does not have a price - default value -> 0
		}
}
